public class Main {
    public static void main(String[] args) {
        int a = 5;
        int b = 3;

        System.out.println("addition: " +(a+b));
        
        System.out.println("subtraction:"+(a-b));
        System.out.println("multiplication:"+(a*b));
        System.out.println("division:"+(a/b));
        System.out.println("modulo:"+(a%b));
        
    }
}
